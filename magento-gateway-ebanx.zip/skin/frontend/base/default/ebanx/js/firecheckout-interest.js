"use strict";var ebanxUpdateFireInterest=function(){checkout.update(checkout.urls.payment_method)};
//# sourceMappingURL=firecheckout-interest.js.map
