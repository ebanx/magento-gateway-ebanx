"use strict";Validation.add("brand-required"," ",function(t){return!Validation.get("IsEmpty").test(t)});
//# sourceMappingURL=validator.js.map
