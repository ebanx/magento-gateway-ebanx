"use strict";var amsCheckoutHandler=function(){return document.querySelector('label[for="billing\\:taxvat_number"]')};
//# sourceMappingURL=amscheckout-inputs.js.map
