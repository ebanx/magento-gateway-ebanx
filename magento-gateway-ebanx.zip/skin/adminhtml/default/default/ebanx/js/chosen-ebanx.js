"use strict";document.observe("dom:loaded",function(){var e=$$('#payment_ebanx_settings select[multiple], #payment_ebanx_settings select[id$="_status"]');e.length&&e.each(function(e){new Chosen(e,{placeholder_text:" ",no_results_text:"Press Enter to add",width:"270px"})})});
//# sourceMappingURL=chosen-ebanx.js.map
