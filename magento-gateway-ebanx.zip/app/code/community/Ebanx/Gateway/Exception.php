<?php

class Ebanx_Gateway_Exception extends Exception
{

}
