<?php

class Ebanx_Gateway_Block_Checkout_Success_Payment_Oxxo extends Ebanx_Gateway_Block_Checkout_Success_Cashpayment
{
	protected function _construct()
	{
		parent::_construct();
	}
}
