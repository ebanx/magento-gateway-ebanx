<?php

class Ebanx_Gateway_Model_Log extends Mage_Core_Model_Abstract
{
	public function __construct()
	{
		$this->_init('ebanx/log');
	}
}
